(function(){
"use strict";
/* ===== CONFIGURE HERE ===== */
var NAME="Fatima", BIRTH_YEAR=2006, BIRTH_MONTH=10, BIRTH_DAY=25; /* month 1-12 */
var SLIDES=[
 {src:"images/photo1.jpg",cap:"Small moments, quietly treasured",g:"linear-gradient(135deg,#4a2f36,#1f1a1d)"},
 {src:"images/photo2.jpg",cap:"Friendship that needs no words",g:"linear-gradient(135deg,#7a4a52,#2a2024)"},
 {src:"images/photo3.jpg",cap:"A proud milestone, earned with dedication",g:"linear-gradient(135deg,#a8707a,#3a2a2f)"},
 {src:"images/photo4.jpg",cap:"Side by side through every season",g:"linear-gradient(135deg,#5a3a42,#1b191c)"},
 {src:"images/photo5.jpg",cap:"Graceful evenings and cherished company",g:"linear-gradient(135deg,#6b4550,#241c20)"},
 {src:"images/photo6.jpg",cap:"Quiet walks and a calm, gentle spirit",g:"linear-gradient(135deg,#8d5560,#2a2024)"}
]; 
var CARDS=[
 ["Your Kindness","You make generosity look effortless, and you never once ask for credit."],
 ["Your Strength","I have seen you carry more than anyone knew, and still show up for others."],
 ["Your Laughter","It is the sound I would recognise anywhere, and the one I would miss most."],
 ["Your Loyalty","You stay. Through every season, you have always stayed."]
];
/* ===== helpers ===== */
var $=function(i){return document.getElementById(i)};
$("who").textContent=NAME;

/* reveal */
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12});
document.querySelectorAll(".reveal").forEach(function(el){io.observe(el)});

/* countdown */
function target(){var n=new Date(),t=new Date(n.getFullYear(),BIRTH_MONTH-1,BIRTH_DAY);if(t<new Date(n.getFullYear(),n.getMonth(),n.getDate()))t=new Date(n.getFullYear()+1,BIRTH_MONTH-1,BIRTH_DAY);return t}
function pad(n){return String(n).padStart(2,"0")}
function tick(){
  var now=new Date(),t=target(),d=t-now;$("cnote").textContent="Until you turn "+(t.getFullYear()-BIRTH_YEAR);
  if(now.getMonth()===BIRTH_MONTH-1&&now.getDate()===BIRTH_DAY){["cd","ch","cm","cs"].forEach(function(i){$(i).textContent="00"});$("cnote").textContent="Today is your day";return}
  var s=Math.floor(d/1000);
  $("cd").textContent=pad(Math.floor(s/86400));$("ch").textContent=pad(Math.floor(s%86400/3600));
  $("cm").textContent=pad(Math.floor(s%3600/60));$("cs").textContent=pad(s%60);
}
tick();setInterval(tick,1000);

/* slider */
var sl=$("slider"),dots=$("dots"),cur=0,timer;
SLIDES.forEach(function(s,i){
  var d=document.createElement("div");d.className="slide"+(i?"":" on");
  d.style.backgroundImage=s.g;d.style.setProperty("--img",s.src?"url('"+s.src+"')":"none");
  d.innerHTML="<p>"+s.cap+"</p>";sl.appendChild(d);
  var b=document.createElement("button");b.className=i?"":"on";b.setAttribute("aria-label","Slide "+(i+1));
  b.onclick=function(){go(i);restart()};dots.appendChild(b);
});
function go(n){
  var a=sl.children,b=dots.children;a[cur].classList.remove("on");b[cur].classList.remove("on");
  cur=(n+a.length)%a.length;a[cur].classList.add("on");b[cur].classList.add("on");
}
function restart(){clearInterval(timer);timer=setInterval(function(){go(cur+1)},5200)}
restart();

/* cards */
var grid=$("grid");
CARDS.forEach(function(c){
  var b=document.createElement("button");b.className="flip";b.setAttribute("aria-pressed","false");
  b.innerHTML='<div class="inner"><div class="face front"><h3>'+c[0]+'</h3><span>Tap to reveal</span></div><div class="face back">'+c[1]+'</div></div>';
  b.onclick=function(){var on=b.classList.toggle("on");b.setAttribute("aria-pressed",on)};
  grid.appendChild(b);
});

/* candle */
var stage=$("stage"),cv=$("burst"),cx=cv.getContext("2d"),parts=[],raf=0;
function burst(){
  var ox=360,oy=170;parts=[];
  for(var i=0;i<46;i++){var a=Math.random()*Math.PI*2,v=1.2+Math.random()*3.4;
    parts.push({x:ox,y:oy,vx:Math.cos(a)*v,vy:Math.sin(a)*v-1.4,r:1+Math.random()*2.2,l:1,d:.008+Math.random()*.012,c:Math.random()<.5?"230,191,180":"192,129,138"})}
  cancelAnimationFrame(raf);(function f(){
    cx.clearRect(0,0,720,720);var alive=false;
    parts.forEach(function(p){if(p.l<=0)return;alive=true;p.x+=p.vx;p.y+=p.vy;p.vx*=.985;p.vy=p.vy*.985+.035;p.l-=p.d;
      cx.beginPath();cx.fillStyle="rgba("+p.c+","+Math.max(p.l,0)+")";cx.arc(p.x,p.y,p.r,0,6.283);cx.fill()});
    if(alive)raf=requestAnimationFrame(f);else cx.clearRect(0,0,720,720);
  })();
}
function toggleCandle(){
  var out=stage.classList.toggle("out");
  $("hint").textContent=out?"May every wish you hold come true":"Touch the flame to blow it out";
  if(out){burst();setTimeout(partyPop,350);applause();}
}
stage.onclick=toggleCandle;
stage.onkeydown=function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();toggleCandle()}};

/* audio */
var AC=null,master=null,muted=false,singing=false;
function audio(){if(!AC){var C=window.AudioContext||window.webkitAudioContext;if(!C)return null;AC=new C();master=AC.createGain();master.gain.value=muted?0:1;master.connect(AC.destination)}if(AC.state==="suspended")AC.resume();return AC}
document.addEventListener("pointerdown",audio,{once:true});
$("snd").onclick=function(){muted=!muted;audio();if(master)master.gain.value=muted?0:1;this.textContent=muted?"Sound Off":"Sound On"};
function note(f,t,d,v){var o=AC.createOscillator(),g=AC.createGain();o.type="triangle";o.frequency.value=f;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+.03);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(master);o.start(t);o.stop(t+d+.05)}
var SONG=[[392,.75],[392,.25],[440,1],[392,1],[523,1],[494,2],[392,.75],[392,.25],[440,1],[392,1],[587,1],[523,2],[392,.75],[392,.25],[784,1],[659,1],[523,1],[494,1],[440,2],[698,.75],[698,.25],[659,1],[523,1],[587,1],[523,2]];
function song(){if(!audio()||singing)return;singing=true;$("songbtn").textContent="Playing";var t=AC.currentTime+.1,b=.55;SONG.forEach(function(n){note(n[0],t,n[1]*b*1.1,.22);note(n[0]/2,t,n[1]*b*1.1,.08);t+=n[1]*b});setTimeout(function(){singing=false;$("songbtn").textContent="Play Birthday Song"},(t-AC.currentTime)*1000+400)}
function noise(t,dur,type,freq,v){var n=Math.floor(AC.sampleRate*dur),buf=AC.createBuffer(1,n,AC.sampleRate),d=buf.getChannelData(0);for(var i=0;i<n;i++)d[i]=Math.random()*2-1;var s=AC.createBufferSource();s.buffer=buf;var f=AC.createBiquadFilter();f.type=type;f.frequency.value=freq;var g=AC.createGain();g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+dur);s.connect(f);f.connect(g);g.connect(master);s.start(t)}
function applause(){if(!audio())return;var t0=AC.currentTime;for(var i=0;i<110;i++){var t=t0+Math.pow(Math.random(),.8)*4.6;noise(t,.07+Math.random()*.06,"bandpass",1200+Math.random()*2200,(.08+Math.random()*.1)*(1-(t-t0)/5.2))}}
function popSound(){var t=AC.currentTime;noise(t,.18,"highpass",1500,.5);var o=AC.createOscillator(),g=AC.createGain();o.frequency.setValueAtTime(320,t);o.frequency.exponentialRampToValueAtTime(60,t+.15);g.gain.setValueAtTime(.4,t);g.gain.exponentialRampToValueAtTime(.0001,t+.18);o.connect(g);g.connect(master);o.start(t);o.stop(t+.2)}
/* confetti */
var cf=$("conf"),cc=cf.getContext("2d"),bits=[],craf=0,COL=["#e6bfb4","#c0818a","#f1dcd2","#d8b9a4","#ffffff","#b98c5a"];
function sizeC(){cf.width=innerWidth;cf.height=innerHeight}sizeC();addEventListener("resize",sizeC);
function partyPop(){
  if(audio())popSound();var W=cf.width,H=cf.height,k=Math.min(1,H/760);
  [[0,1],[W,-1]].forEach(function(s){for(var i=0;i<85;i++){var a=.15+Math.random()*.6,v=(10+Math.random()*12)*k+4;
    bits.push({x:s[0],y:H,vx:s[1]*Math.sin(a)*v,vy:-Math.cos(a)*v,w:5+Math.random()*6,h:3+Math.random()*4,r:Math.random()*6,vr:(Math.random()-.5)*.3,c:COL[i%COL.length]})}});
  cancelAnimationFrame(craf);(function f(){
    cc.clearRect(0,0,cf.width,cf.height);
    bits=bits.filter(function(p){p.vy+=.28;p.vx*=.992;p.vy*=.992;p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;return p.y<cf.height+30});
    bits.forEach(function(p){cc.save();cc.translate(p.x,p.y);cc.rotate(p.r);cc.fillStyle=p.c;cc.fillRect(-p.w/2,-p.h/2,p.w,p.h*Math.abs(Math.cos(p.r*2)+.2));cc.restore()});
    if(bits.length)craf=requestAnimationFrame(f);
  })();
}
$("popbtn").onclick=partyPop;$("songbtn").onclick=song;$("clapbtn").onclick=applause;

/* gift and book */
var gb=$("giftbtn"),gs=$("giftstage"),started=false,ready=false;
$("bkname").textContent=NAME;$("bkname2").textContent=NAME;
gb.onclick=function(){
  if(started)return;started=true;gb.classList.add("opening");
  setTimeout(function(){gs.classList.add("rise")},1500);
  setTimeout(function(){gs.classList.add("floating","opened");$("gifthint").textContent="Written for you, with love";setTimeout(partyPop,3800);ready=true},5000);
};
$("bookwrap").onclick=function(){if(ready)gs.classList.toggle("opened")};
})();
